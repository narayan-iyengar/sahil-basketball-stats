import React, { useEffect, useState } from "react";
import { doc, onSnapshot, updateDoc, increment } from "firebase/firestore";
import StatStepperGroup from "./StatStepperGroup";
import StatStepper from "./StatStepper";
import SaveStatusIndicator from "./SaveStatusIndicator";
import { ShareIcon } from "./icons";
import { setPresence, removePresence } from "./presence";
import { rtdb } from "./firebase";


export default function LiveGameAdmin({ db, gameId, appId, user, onEndGame }) {
  const [game, setGame] = useState(null);
  const [shareMessage, setShareMessage] = useState("");
  const statKeys = ["fg2m", "fg2a", "fg3m", "fg3a", "ftm", "fta", "rebounds", "assists", "steals", "blocks", "fouls", "turnovers"];

  const initialStatus = statKeys.reduce((acc, key) => {
    acc[key] = null;
    return acc;
  }, {});
  const [saveStatus, setSaveStatus] = useState(initialStatus);


  useEffect(() => {
    if (!user) return;
    setPresence(user, "admin");
    return () => removePresence(user, "admin");
  }, [user]);


const [admins, setAdmins] = useState([]);
useEffect(() => {
  if (!user || !gameId) return;
  const presenceRef = setPresence(rtdb, "global", user, setAdmins);
  const off = listenPresence(rtdb, "global", user, setAdmins);
  return () => {
    removePresence(rtdb, gameId, user, "admins");
    if (typeof off === "function") off();
  };
}, [user, gameId]);



  const showSaveIndicator = async (key, updatePromise) => {
    setSaveStatus(prev => ({ ...prev, [key]: "saving" }));
    try {
      await updatePromise;
      setSaveStatus(prev => ({ ...prev, [key]: "success" }));
    } catch (error) {
      setSaveStatus(prev => ({ ...prev, [key]: "error" }));
    } finally {
      setTimeout(() => {
        setSaveStatus(prev => ({ ...prev, [key]: null }));
      }, 1200);
    }
  };

  useEffect(() => {
    const unsub = onSnapshot(doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`), docSnap => {
      if (docSnap.exists()) {
        setGame({ id: docSnap.id, ...docSnap.data() });
      } else {
        setGame(null);
      }
    });
    return () => unsub();
  }, [db, gameId, appId]);

  useEffect(() => {
    if (game?.isRunning && game.clock > 0) {
      const interval = setInterval(() => {
        const gameRef = doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`);
        updateDoc(gameRef, { clock: increment(-1) });
      }, 1000);
      return () => clearInterval(interval);
    } else if (game?.isRunning && game.clock <= 0) {
      const gameRef = doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`);
      const isGameOver = (game.gameFormat === "halves" && game.period >= 2) || (game.gameFormat === "periods" && game.period >= 4);

      const updates = { isRunning: false };
      if (!isGameOver) {
        updates.period = increment(1);
        updates.clock = game.periodLength;
      }
      updateDoc(gameRef, updates);
    }
  }, [game, db, gameId, appId]);

  const handleScoreChange = (team, delta) => {
    if (!game) return;
    const key = team === "home" ? "homeScore" : "awayScore";
    if (delta < 0 && game[key] <= 0) return;
    const updates = { [key]: increment(delta) };
    if (!game.isRunning) updates.isRunning = true;
    const updatePromise = updateDoc(doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`), updates);
    showSaveIndicator(key, updatePromise);
  };

  const handleStatChange = (stat, delta) => {
    const gameRef = doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`);
    const currentStats = game.playerStats;
    const newValue = Math.max(0, currentStats[stat] + delta);

    const updates = { [`playerStats.${stat}`]: newValue };
    if (!game.isRunning) updates.isRunning = true;

    // When a "made" is incremented, also increment "attempted"
    if (delta > 0) {
      if (stat === "fg2m") updates.homeScore = increment(2);
      if (stat === "fg3m") updates.homeScore = increment(3);
      if (stat === "ftm") updates.homeScore = increment(1);
    } else if (delta < 0) {
      if (stat === "fg2m" && currentStats.fg2m > 0) updates.homeScore = increment(-2);
      if (stat === "fg3m" && currentStats.fg3m > 0) updates.homeScore = increment(-3);
      if (stat === "ftm" && currentStats.ftm > 0) updates.homeScore = increment(-1);
    }
    if (stat === "fg2m" && delta > 0 && newValue > currentStats.fg2a) updates["playerStats.fg2a"] = newValue;
    if (stat === "fg2a" && delta < 0 && newValue < currentStats.fg2m) updates["playerStats.fg2m"] = newValue;
    if (stat === "fg3m" && delta > 0 && newValue > currentStats.fg3a) updates["playerStats.fg3a"] = newValue;
    if (stat === "fg3a" && delta < 0 && newValue < currentStats.fg3m) updates["playerStats.fg3m"] = newValue;
    if (stat === "ftm" && delta > 0 && newValue > currentStats.fta) updates["playerStats.fta"] = newValue;
    if (stat === "fta" && delta < 0 && newValue < currentStats.ftm) updates["playerStats.ftm"] = newValue;

    const updatePromise = updateDoc(gameRef, updates);
    showSaveIndicator(stat, updatePromise);
  };

  const toggleClock = () => {
    const updatePromise = updateDoc(doc(db, `/artifacts/${appId}/public/data/liveGames/${gameId}`), { isRunning: !game.isRunning });
    showSaveIndicator("clock", updatePromise);
  };

  const handleShare = () => {
    const shareableLink = `${window.location.origin}${window.location.pathname}?liveGameId=${gameId}`;
    navigator.clipboard.writeText(shareableLink);
    setShareMessage("Copied!");
    setTimeout(() => setShareMessage(""), 2000);
  };

  if (!game) return <div className="text-center p-10">Loading Live Game...</div>;

  const formatTime = (seconds) => `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const playerStats = game.playerStats || {};
  const periodName = game.gameFormat === "halves" ? "Half" : "Period";

  return (
    <div className="max-w-md mx-auto space-y-4 pb-24">
      <div className="bg-white dark:bg-gray-800 p-3 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 relative">
        <div className="absolute top-2 right-2"><SaveStatusIndicator status={saveStatus["clock"]} /></div>
        <div className="flex justify-around items-center text-center">
          <div className="w-1/3"><h3 className="text-lg font-bold truncate flex items-center justify-center">{game.homeTeam} <SaveStatusIndicator status={saveStatus["homeScore"]} /></h3><p className="text-5xl font-mono">{game.homeScore}</p></div>
          <div className="w-1/3"><p className="text-4xl font-mono tracking-wider">{formatTime(game.clock)}</p><p className="text-sm text-gray-500 dark:text-gray-400 capitalize">{periodName} {game.period}</p></div>
          <div className="w-1/3"><h3 className="text-lg font-bold truncate flex items-center justify-center">{game.awayTeam} <SaveStatusIndicator status={saveStatus["awayScore"]} /></h3><p className="text-5xl font-mono">{game.awayScore}</p></div>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-700 p-1.5 rounded-lg"><button onClick={() => handleScoreChange("home", -1)} className="bg-red-500 w-7 h-7 rounded-md text-lg font-bold disabled:opacity-50" disabled={game.homeScore <= 0}>-</button><span className="font-semibold text-sm px-1">{game.homeTeam}</span><button onClick={() => handleScoreChange("home", 1)} className="bg-green-500 w-7 h-7 rounded-md text-lg font-bold">+</button></div>
          <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-700 p-1.5 rounded-lg"><button onClick={() => handleScoreChange("away", -1)} className="bg-red-500 w-7 h-7 rounded-md text-lg font-bold disabled:opacity-50" disabled={game.awayScore <= 0}>-</button><span className="font-semibold text-sm px-1">{game.awayTeam}</span><button onClick={() => handleScoreChange("away", 1)} className="bg-green-500 w-7 h-7 rounded-md text-lg font-bold">+</button></div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-bold text-center text-orange-500 mb-4">Sahil's Live Stats</h3>
        <div className="space-y-4">
          <StatStepperGroup label="2-Pointers" madeValue={playerStats.fg2m} attValue={playerStats.fg2a} onStatChange={handleStatChange} madeKey="fg2m" attKey="fg2a" saveStatus={saveStatus}/>
          <StatStepperGroup label="3-Pointers" madeValue={playerStats.fg3m} attValue={playerStats.fg3a} onStatChange={handleStatChange} madeKey="fg3m" attKey="fg3a" saveStatus={saveStatus}/>
          <StatStepperGroup label="Free Throws" madeValue={playerStats.ftm} attValue={playerStats.fta} onStatChange={handleStatChange} madeKey="ftm" attKey="fta" saveStatus={saveStatus}/>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-4 mt-4 border-t border-gray-200 dark:border-gray-700">
          <StatStepper label="Rebounds" value={playerStats.rebounds} onIncrement={() => handleStatChange("rebounds", 1)} onDecrement={() => handleStatChange("rebounds", -1)} saveStatus={saveStatus["rebounds"]}/>
          <StatStepper label="Assists" value={playerStats.assists} onIncrement={() => handleStatChange("assists", 1)} onDecrement={() => handleStatChange("assists", -1)} saveStatus={saveStatus["assists"]}/>
          <StatStepper label="Steals" value={playerStats.steals} onIncrement={() => handleStatChange("steals", 1)} onDecrement={() => handleStatChange("steals", -1)} saveStatus={saveStatus["steals"]}/>
          <StatStepper label="Blocks" value={playerStats.blocks} onIncrement={() => handleStatChange("blocks", 1)} onDecrement={() => handleStatChange("blocks", -1)} saveStatus={saveStatus["blocks"]}/>
          <StatStepper label="Fouls" value={playerStats.fouls} onIncrement={() => handleStatChange("fouls", 1)} onDecrement={() => handleStatChange("fouls", -1)} saveStatus={saveStatus["fouls"]}/>
          <StatStepper label="Turnovers" value={playerStats.turnovers} onIncrement={() => handleStatChange("turnovers", 1)} onDecrement={() => handleStatChange("turnovers", -1)} saveStatus={saveStatus["turnovers"]}/>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm p-3 border-t border-gray-200 dark:border-gray-700 z-10">
        <div className="grid grid-cols-3 gap-3 max-w-md mx-auto">
          <button onClick={handleShare} className="w-full py-3 rounded-lg font-bold text-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center">
            {shareMessage ? shareMessage : <ShareIcon />}
          </button>
          <button onClick={toggleClock} className={`w-full py-3 rounded-lg font-bold text-lg ${game.isRunning ? "bg-yellow-500 text-black" : "bg-green-500 text-white"}`}>{game.isRunning ? "Pause" : "Start"}</button>
          <button onClick={() => onEndGame(game)} className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 rounded-lg text-lg">End</button>
        </div>
      </div>
    </div>
  );
}

