import React from "react";
import {
  LogOutIcon,
  SunIcon,
  MoonIcon,
  ChartIcon,
  BasketballIcon,
  EyeIcon,
  UserIcon,
} from "./icons";

// Avatar component
const Avatar = ({ user, size = 30 }) => (
  <div
    className="rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center overflow-hidden border border-gray-300 dark:border-gray-700"
    style={{ width: size, height: size }}
    title={user?.name || ""}
  >
    {user?.photoURL ? (
      <img
        src={user.photoURL}
        alt={user.name}
        className="w-full h-full object-cover"
        draggable="false"
      />
    ) : (
      <span className="text-gray-600 dark:text-gray-200 font-semibold text-base">
        {user?.name?.split(" ").map(s => s[0]).join("") || <UserIcon />}
      </span>
    )}
  </div>
);

export default function Header({
  user,
  admins = [],
  viewers = [],
  onSignOut,
  setPage,
  theme,
  toggleTheme,
  page,
}) {
  // Defensive: Always use arrays
  const adminList = Array.isArray(admins) ? admins : [];
  const viewerList = Array.isArray(viewers) ? viewers : [];

  // Render user list tooltip
  const renderUserList = users =>
    Array.isArray(users) && users.length ? (
      <ul className="text-xs text-gray-800 dark:text-gray-200">
        {users.map((u, i) => (
          <li key={u.uid || i}>
            {u.name || "Unknown"} {u.uid === user?.uid && <span className="text-orange-500">(You)</span>}
          </li>
        ))}
      </ul>
    ) : (
      <span className="text-xs text-gray-400">No one online</span>
    );

  return (
    <header className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm sticky top-0 z-20 border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto flex justify-between items-center p-4">
        {/* Left-aligned Logo & Title */}
        <div className="flex items-center cursor-pointer" onClick={() => setPage("game_setup")}>
          <BasketballIcon className="h-7 w-7 text-orange-500 animate-spin-slow" />
          <h1 className="text-xl font-bold text-orange-500 ml-2">Sahil's Stats</h1>
        </div>

        {/* Presence/Avatars */}
        <div className="flex items-center gap-4">
          {/* Admins */}
          <div className="flex items-center group relative">
            <UserIcon className="w-5 h-5 text-blue-400 mr-1" />
            <span className="text-xs text-gray-600 dark:text-gray-300 font-semibold">{adminList.length}</span>
            <div className="flex -space-x-2 ml-2">
              {adminList.map((a, i) => (
                <span key={a.uid || i} className="border-2 border-white dark:border-gray-700">
                  <Avatar user={a} size={24} />
                </span>
              ))}
            </div>
            {/* Tooltip on hover */}
            <div className="absolute top-full left-0 mt-2 p-2 rounded bg-white dark:bg-gray-900 shadow text-xs z-40 w-48 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity duration-200">
              <b>Admins:</b>
              {renderUserList(adminList)}
            </div>
          </div>
          {/* Viewers */}
          <div className="flex items-center group relative">
            <EyeIcon className="w-5 h-5 text-green-400 mr-1" />
            <span className="text-xs text-gray-600 dark:text-gray-300 font-semibold">{viewerList.length}</span>
            <div className="flex -space-x-2 ml-2">
              {viewerList.map((v, i) => (
                <span key={v.uid || i} className="border-2 border-white dark:border-gray-700">
                  <Avatar user={v} size={24} />
                </span>
              ))}
            </div>
            {/* Tooltip on hover */}
            <div className="absolute top-full left-0 mt-2 p-2 rounded bg-white dark:bg-gray-900 shadow text-xs z-40 w-48 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity duration-200">
              <b>Viewers:</b>
              {renderUserList(viewerList)}
            </div>
          </div>
        </div>

        {/* Controls: Theme, Dashboard, Sign Out */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            className="flex items-center bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-3 rounded-lg text-sm"
          >
            {theme === "light" ? <MoonIcon /> : <SunIcon />}
          </button>
          <button
            onClick={() => setPage("dashboard")}
            className="flex items-center bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-3 rounded-lg text-sm"
          >
            <ChartIcon />
            <span className="hidden sm:inline sm:ml-2">Dashboard</span>
          </button>
          <button
            onClick={onSignOut}
            className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-3 rounded-lg text-sm flex items-center"
          >
            <LogOutIcon />
            <span className="hidden sm:inline sm:ml-2">Sign Out</span>
          </button>
        </div>
      </div>
    </header>
  );
}

