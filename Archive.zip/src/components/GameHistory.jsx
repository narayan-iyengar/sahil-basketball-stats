import React, { useState } from "react";
import { ChevronRightIcon, TrashIcon } from "../icons";

const statFields = [
  { label: "PTS", key: "points" },
  { label: "2PT", key: "fg2m", sublabel: "made/att", paired: "fg2a" },
  { label: "3PT", key: "fg3m", sublabel: "made/att", paired: "fg3a" },
  { label: "FT", key: "ftm", sublabel: "made/att", paired: "fta" },
  { label: "REB", key: "rebounds" },
  { label: "AST", key: "assists" },
  { label: "STL", key: "steals" },
  { label: "BLK", key: "blocks" },
  { label: "FLS", key: "fouls" },
  { label: "TO", key: "turnovers" },
];

export default function GameHistory({ stats = [], onDeleteGame }) {
  const [expandedGameIds, setExpandedGameIds] = useState([]);

  const toggleExpandGame = (id) => {
    setExpandedGameIds((prev) =>
      prev.includes(id) ? prev.filter((gid) => gid !== id) : [...prev, id]
    );
  };

  return (
    <div>
      {stats.map((game) => (
        <div
          key={game.id}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-600 mb-4"
        >
          <div
            onClick={() => toggleExpandGame(game.id)}
            className="flex justify-between p-4 cursor-pointer"
          >
            <div>
              <p className="font-bold text-lg text-gray-900 dark:text-white">
                {new Date(game.timestamp).toLocaleString()}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-300">
                {game.teamName} vs {game.opponent}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold">
                {game.myTeamScore}-{game.opponentScore}
              </span>
              <button
                onClick={e => {
                  e.stopPropagation();
                  onDeleteGame(game.id); // Opens confirm dialog in Dashboard
                }}
                title="Delete Game"
                className="p-2 rounded hover:bg-red-100 dark:hover:bg-red-900/40"
              >
                <TrashIcon className="text-red-400 hover:text-red-600" />
              </button>
              <ChevronRightIcon
                className={`${expandedGameIds.includes(game.id) ? "rotate-90" : ""}`}
              />
            </div>
          </div>

          {expandedGameIds.includes(game.id) && (
            <div className="p-4 border-t border-gray-200 dark:border-gray-600">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {statFields.map((stat) =>
                  stat.paired ? (
                    <div key={stat.key} className="flex flex-col items-center">
                      <span className="text-orange-500 font-semibold">{stat.label}</span>
                      <span className="text-sm text-gray-400">{stat.sublabel}</span>
                      <span className="text-lg font-bold text-gray-900 dark:text-white">
                        {game[stat.key] ?? 0}/{game[stat.paired] ?? 0}
                      </span>
                    </div>
                  ) : (
                    <div key={stat.key} className="flex flex-col items-center">
                      <span className="text-orange-500 font-semibold">{stat.label}</span>
                      <span className="text-lg font-bold text-gray-900 dark:text-white">
                        {game[stat.key] ?? 0}
                      </span>
                    </div>
                  )
                )}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

